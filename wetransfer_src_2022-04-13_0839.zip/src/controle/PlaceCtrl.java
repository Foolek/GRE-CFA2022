package controle;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JOptionPane;

import dao.PlaceDao;
import dao.TripDao;
import entites.Place;
import entites.Trip;
import persistance.ConnectionManager;
import persistance.DaoFactory;

public class PlaceCtrl {

	private static PlaceDao placeDao;
	private static TripDao tripDao;
	Place place;
	Scanner sc;
	String name;

	public PlaceCtrl(DaoFactory myDaoFactory) {
		placeDao = myDaoFactory.getPlaceDao();
		tripDao = myDaoFactory.getTripDao();

		place = null;
		name = null;
	}

	public List<Place> findAllPlaces() {
		List<Place> places = new ArrayList<>();
		places = placeDao.findAllPlaces();
		if (places == null) {
			System.out.println("Impossible de trouver cette ville");
		}

		return places;
	}
	
	/*public void AfficherVoyage() {
		String query = "SELECT depart, arrivee, prix FROM voyage";
		Statement stm = null;
		ResultSet rs = null;

		try {
			rs = stm.executeQuery(query);

			while (rs.next()) {
				Place depart = placeDao.findPlaceById(rs.getInt(1));
				Place destination = placeDao.findPlaceById(rs.getInt(1));
			}
		} catch (SQLException e) {
			e.getMessage();
		}
	}*/

	public void addTrip() {

		System.out.println("Taper l'ID de la ville de d�part: ");
		int idDepart = sc.nextInt();

		Trip trip = new Trip();

		Place depart = new Place();
		depart.setId(idDepart);
		trip.setDepart(depart);

		System.out.println("Taper l'ID de la ville de destination: ");
		int idDest = sc.nextInt();

		Place destination = new Place();
		destination.setId(idDest);
		trip.setDestination(destination);

		System.out.println("Taper le prix: ");
		int price = sc.nextInt();
		trip.setPrice(price);
		int id = tripDao.createTrip(trip);
		System.out.println("Voyage cr�� avec l'ID: " + id);
	}

	public void exit() {
		System.out.println("CIAO CIAO");
		ConnectionManager.close();
		sc.close();
		System.exit(-1);

	}

	public void addPlace(String name) {
		place = new Place(name);
		if (name == null) {
			JOptionPane.showMessageDialog(null, "aucun nom de ville saisi");
		} else {
			int id = placeDao.createPlace(place);
			if (id != 0)
				System.out.println("Ville ajout�e avec l'ID: " + id);
			else
				System.out.println("Echec � l'ajout de la ville.");
		}
		// sc.close();
	}

	public void removePlace(Place place) {
		int b_confirmdel = JOptionPane.showConfirmDialog(null, "Voulez vous vraiment supprimer la ville ?",
				"Suprression de la ville", JOptionPane.ERROR_MESSAGE);

		if (b_confirmdel == 0) {
			if (placeDao.removePlace(place)) {
				JOptionPane.showMessageDialog(null, "Ville supprim�e avec succ�s.", "Suppression de la ville",
						JOptionPane.DEFAULT_OPTION);
			}
		}

	}

	/*
	 * public void findPlace() {
	 * 
	 * place = placeDao.findPlaceById(id); if (place == null) {
	 * System.out.println("Impossible de trouver la ville correspondant � cet ID");
	 * } else { System.out.println("Nom de la ville: " + place.getName()); } }
	 */

	/*
	 * public void editPlace() {
	 * 
	 * findPlace();
	 * 
	 * System.out.println("Entrez le nouveau nom: "); name = sc.next(); sc.close();
	 * place.setName(name);
	 * 
	 * if (placeDao.updatePlace(place)) {
	 * System.out.println("Le nom a �t� modifi� avec succ�s"); } else {
	 * System.out.println("Impossible de trouver la ville correspondant � cet ID");
	 * } }
	 */

}
