package dao;

import entites.Trip;

public interface TripDao {

	int createTrip(Trip trip);

}