package dao;

import java.util.List;

import entites.Place;

public interface PlaceDao {

	int createPlace(Place place);

	Place findPlaceById(int id);

	boolean updatePlace(Place place);

	boolean removePlace(Place place);

	List<Place> findAllPlaces();
}